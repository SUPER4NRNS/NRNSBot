# config.py

owner_id = [
    "1010332940"
]  # 机器人root管理员 QQ 号，可以有多个，多个时，需要用英文逗号分隔，上线通知只会给第一个

report_group_id = "294824017"  # 上报群

ws_url = "ws://192.168.3.7:3001"  # 本地环境的 WebSocket API 地址

token = None  # 如果需要认证，请填写认证 token

DD_BOT_TOKEN = "dingtalk_token"

DD_BOT_SECRET = "dingtalk_secret"
