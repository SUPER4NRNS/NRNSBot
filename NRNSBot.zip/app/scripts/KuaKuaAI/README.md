# KuaKuaAI

对接夸夸 AI 的 API 实现群内聊天 https://api.aa1.cn/doc/quark.html#/

## 更新日志

- 2024-12-05 添加夸夸 AI 开关管理
