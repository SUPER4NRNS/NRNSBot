# QRCodeInspector
二维码巡查者，监控群内图片，对所有二维码进行撤回
